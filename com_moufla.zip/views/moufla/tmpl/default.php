<?php
// No direct access to this file
defined('_JEXEC') or die('Restricted access');
?>
<h1><?php echo $this->msg; ?></h1>
<div><?php echo "L'id est: ".$this->id.". Et la description est: ".$this->desc."."; ?></div>